import { useState } from "react";
import styles from "./Main.module.css";
import { IRoles } from "../../interfaces";
import {
  addMe,
  setStatus,
  setTokenF,
  takeRoles,
  takeToken,
} from "../../service/service";
const Main = () => {
  const [roles, setRoles] = useState<IRoles>();
  const [data, setData] = useState({
    last_name: "",
    first_name: "",
    email: "",
    role: "Системный аналитик",
  });
  const [token, setToken] = useState("");
  const [emailForToken, setEmailForToken] = useState("");
  const [baseToken, setBaseToken] = useState("");
  async function takeRolesF() {
    try {
      const response = await takeRoles();
      setRoles(response);
    } catch (err) {
      console.log(err);
    }
  }
  async function addMeF() {
    try {
      const response = await addMe(data);
      alert(response);
    } catch (err) {
      console.log(err);
    }
  }
  async function takeTokenF() {
    try {
      const response: string = await takeToken(emailForToken);
      await setToken(response);
      alert(response);
    } catch (err) {
      console.log(err);
    }
  }
  async function setStatusF() {
    if (token === "") {
      alert("Вы еще не получили token");
      return;
    }
    try {
      const response = await setTokenF(emailForToken, token)
        .then(async (response) => {
          const responseBase64 = await setStatus(response.token);
          setBaseToken(response.token);
          console.log(responseBase64);
        })
        .catch((err) => console.log(err));
    } catch (err) {
      console.log(err);
    }
  }
  return (
    <>
      <h2>Получить роли</h2>
      <div className={styles.block}>
        <button onClick={takeRolesF} className={styles.btn}>
          Получить
        </button>
        {roles ? (
          <ul className={styles.role_block}>
            {roles.roles.map((name) => {
              return (
                <li className={styles.role}>
                  <p>{name}</p>
                </li>
              );
            })}
          </ul>
        ) : (
          <div></div>
        )}
      </div>
      <h2>Добавление в бд</h2>
      <div className={styles.block}>
        <div className={styles.addBlock}>
          <span>
            <p>Фамилия</p>
            <input
              value={data.last_name}
              type="text"
              className={styles.addInp}
              onChange={(e) => {
                setData((prev) => {
                  return { ...prev, last_name: e.target.value };
                });
              }}
            />
          </span>
          <span>
            <p>Имя</p>
            <input
              value={data.first_name}
              type="text"
              className={styles.addInp}
              onChange={(e) => {
                setData((prev) => {
                  return { ...prev, first_name: e.target.value };
                });
              }}
            />
          </span>
          <span>
            <p>Почта</p>
            <input
              value={data.email}
              type="email"
              className={styles.addInp}
              onChange={(e) => {
                setData((prev) => {
                  return { ...prev, email: e.target.value };
                });
              }}
            />
          </span>
          <span>
            <p>Роль</p>
            <select
              value={data.role}
              onChange={(e) =>
                setData((prevData) => ({
                  ...prevData,
                  role: e.target.value,
                }))
              }
            >
              <option value="Системный аналитик">Системный аналитик</option>
              <option value="Разработчик Java">Разработчик Java</option>
              <option value="Разработчик JS/React">Разработчик JS/React</option>
              <option value="Тестировщик">Тестировщик</option>
              <option value="Прикладной администратор">
                Прикладной администратор
              </option>
            </select>
          </span>
          <button onClick={addMeF} className={styles.btn}>
            Добавить
          </button>
        </div>
      </div>
      <h2>Получить токен</h2>
      <div className={styles.block}>
        <div className={styles.addBlock}>
          <button
            onClick={takeTokenF}
            className={styles.btn}
            style={{ marginRight: "50px" }}
          >
            Получить
          </button>
          <span>
            <p>Email</p>
            <input
              value={emailForToken}
              type="email"
              className={styles.addInp}
              onChange={(e) => {
                setEmailForToken(e.target.value);
              }}
            />
          </span>
        </div>
      </div>
      <h2>Получить замаскированный email:token</h2>
      <div className={styles.block}>
        <div className={styles.addBlock}>
          <button
            onClick={setStatusF}
            className={styles.btn}
            style={{ marginRight: "50px" }}
          >
            Получить
          </button>
        </div>
        {baseToken === "" ? (
          <></>
        ) : (
          <p className={styles.baseText}>
            Полученный зашифрованный email:token - {baseToken}
          </p>
        )}
      </div>
    </>
  );
};
export default Main;
