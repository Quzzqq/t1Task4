import styles from "./Header.module.css";

const Header = () => {
  return (
    <header className={styles.block}>
      <p>Вызов всех методов</p>
    </header>
  );
};
export default Header;
