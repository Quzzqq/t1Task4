import { useState } from "react";
import styles from "./App.module.css";
import "./App.css";
import Header from "./components/header/Header";
import Main from "./components/main/Main";

function App() {
  return (
    <div className={styles.block}>
      <Header />
      <Main />
    </div>
  );
}

export default App;
