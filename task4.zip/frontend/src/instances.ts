import axios from "axios";

export const instanceTOne = axios.create({
  baseURL: "http://193.19.100.32:7000/api",
});

export const instanceEncode = axios.create({
  baseURL: "http://localhost:4444",
});
