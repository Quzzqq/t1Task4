export interface IRoles {
  roles: [string, string, string, string, string];
}

export interface IData {
  last_name: String;
  first_name: String;
  email: String;
  role: String;
}
