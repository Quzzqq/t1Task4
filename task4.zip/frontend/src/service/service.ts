import axios from "axios";
import { IData, IRoles } from "../interfaces";
import { instanceEncode, instanceTOne } from "../instances";

export const takeRoles = async () => {
  try {
    const response = await instanceTOne.get("/get-roles");
    return response.data as IRoles;
  } catch (err) {
    console.error(err);
  }
};

export const addMe = async (data: IData) => {
  try {
    const response = await instanceTOne.post("/sign-up", {
      last_name: data.last_name,
      first_name: data.first_name,
      email: data.email,
      role: data.role,
    });
    return response.data;
  } catch (err) {
    console.error(err);
  }
};

export const takeToken = async (email: string) => {
  try {
    const response = await instanceTOne.get(`/get-code?email=${email}`);
    return response.data;
  } catch (err) {
    console.error(err);
  }
};

export const setTokenF = async (email: string, token: string) => {
  try {
    const response = await instanceEncode.post("/encode", { email, token });
    return response.data;
  } catch (err) {
    console.log(err);
  }
};

export const setStatus = async (token: string) => {
  try {
    const response = await axios.post(
      "http://193.19.100.32:7000/api/set-status",
      {
        token: token,
        status: "increased",
      }
    );
    return response.data;
  } catch (error) {
    console.error("Ошибка при получении ролей:", error);
  }
};
